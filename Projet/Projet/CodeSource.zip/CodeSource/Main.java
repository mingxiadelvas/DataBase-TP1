package source;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Console;

import javax.swing.*;


public class Main {
	
	static JFrame f = new JFrame();
	static JPanel pane= (JPanel)f.getContentPane();
	static Connection connection = null;
	static PreparedStatement statement1 = null;
	static PreparedStatement statement2 = null;
	static PreparedStatement statement3 = null;
	static PreparedStatement statement4 = null;
	static ResultSet resultSet = null;

		
	public static void resetpage() {
		f.getContentPane().removeAll();
		f.repaint();
		f.setSize(700, 350);
		f.getContentPane().setLayout(null);
		f.setVisible(true);
	}
	//pour aerer le code en preparant une nouvelle page
	
	public static void reconnectAlertBox() {
		JFrame f2 = new JFrame();
		JPanel pane=(JPanel)f2.getContentPane();
		f2.getContentPane().removeAll();
		f2.repaint();
		f2.setSize(300, 300);
		f2.getContentPane().setLayout(null);
		f2.setVisible(true);

		
		JLabel alert = new JLabel("failed to connect");
		alert.setBounds(90, 0,150,50);
		f2.add(alert);
		
		
		JLabel alert2 = new JLabel("enter one of your local psql DB info");
		alert2.setBounds(37, 30,220,50);
		f2.add(alert2);
		
		
		JLabel portAlert = new JLabel("port:");
		portAlert.setBounds(10,85,100,25);
		f2.add(portAlert);
		
		JTextField port = new JTextField();
		port.setBounds(70,85,140,25);
		f2.add(port);
		
		
		
		
		JLabel userAlert = new JLabel("user:");
		userAlert.setBounds(10,120,100,25);
		f2.add(userAlert);
		
		JTextField user = new JTextField();
		user.setBounds(70,120,140,25);
		f2.add(user);
		
		
		
		
		JLabel passAlert = new JLabel("password:");
		passAlert.setBounds(10,155,100,25);
		f2.add(passAlert);
		
		JTextField pass = new JTextField();
		pass.setBounds(70,155,140,25);
		f2.add(pass);
		
		
		
		JButton reconnect = new JButton("connect");
		reconnect.setBounds(90,190,100,25);
		f2.add(reconnect);
		
		f2.repaint();
		
		
		class Click implements ActionListener {
			public void actionPerformed(ActionEvent e) {
				try {
					String portInput = "jdbc:postgresql://localhost/" + port.getText();
					String userInput = user.getText();
					String passInput = pass.getText();
					connection = DriverManager.getConnection(portInput,userInput,passInput);
					alert.setText("connection successful!");
					
					mainPage();
					System.out.println("this");
				}
				catch(SQLException e1) {
					//e.printStackTrace();
					System.out.println("connection failed, attempting again");
					JOptionPane.showMessageDialog(f2, "connection failed");
					alert.setText("failed to connect");
				}
			}
		}
		reconnect.addActionListener(new Click());

	}

	public static void mainPage() {
		resetpage();
		
		//JOptionPane.showMessageDialog(f, "hello");

		
		JButton Q1 = new JButton("Question 1");
		Q1.setBounds(25,50,100,25);
		pane.add(Q1);
		
		JButton Q2 = new JButton("Question 2");
		Q2.setBounds(25,100,100,25);
		pane.add(Q2);
		
		JButton Q3 = new JButton("Question 3");
		Q3.setBounds(25,150,100,25);
		pane.add(Q3);
		
		JButton Q4 = new JButton("Question 4");
		Q4.setBounds(25,200,100,25);
		pane.add(Q4);
		
		
		
		ArrayList<String> answerList = new ArrayList<String>();
		
		JList alertList = new JList();
		JScrollPane alert = new JScrollPane(alertList);
		alert.setBounds(150,50,500,175);
		pane.add(alert);
		
		
		try {
			statement1 = connection.prepareStatement("SELECT Genre.genre, count(*) AS nbr_livre \r\n"
					+ "FROM Genre\r\n"
					+ "JOIN Emprunt ON Genre.Livre_id = Emprunt.Livre_id\r\n"
					+ "GROUP BY genre;");
			
			
			statement2 = connection.prepareStatement("SELECT Commande_id, Nom \r\n"
					+ "FROM Commande\r\n"
					+ "INNER JOIN Membre ON Commande.Membre_id = Membre.Membre_id;");
			
			
			statement3 = connection.prepareStatement("SELECT Titre\r\n"
					+ "FROM Genre\r\n"
					+ "INNER JOIN Livre ON Genre.Livre_id = Livre.Livre_id\r\n"
					+ "WHERE (Genre='Crime');");
			
			
			statement4 = connection.prepareStatement("SELECT Date_emprunt, count(*) AS nbr_emprunt \r\n"
					+ "FROM Emprunt\r\n"
					+ "GROUP BY Date_emprunt; ");
			
			
			
		} catch (SQLException e) {e.printStackTrace();}
		
		class Click implements ActionListener {
			public void actionPerformed(ActionEvent e) {
				
				try {
					if(e.getSource()==Q1) {
						resultSet = statement1.executeQuery();
						while(resultSet.next()) answerList.add(resultSet.getString(1).strip()+','+resultSet.getString(2));
						alertList.setListData(answerList.toArray());
						f.repaint();
						}
					
					else if(e.getSource()==Q2) {
						resultSet = statement2.executeQuery();
						while(resultSet.next())answerList.add(resultSet.getString(1).strip()+','+resultSet.getString(2));
						alertList.setListData(answerList.toArray());
						f.repaint();
						}
					
					else if(e.getSource()==Q3) {
						resultSet = statement3.executeQuery();
						while(resultSet.next())answerList.add(resultSet.getString(1));
						alertList.setListData(answerList.toArray());
						f.repaint();
					}
					
					else if(e.getSource()==Q4) {
						resultSet = statement4.executeQuery();
						while(resultSet.next())answerList.add(resultSet.getString(1).strip()+','+resultSet.getString(2));
						alertList.setListData(answerList.toArray());
						f.repaint();
					};
				}
				catch(SQLException e1) {
					e1.printStackTrace();
				}
			}
		}
		
		
		Q1.addActionListener(new Click());
		Q2.addActionListener(new Click());
		Q3.addActionListener(new Click());
		Q4.addActionListener(new Click());
		
		
		f.repaint();
	}
	
		

	public static void main(String[] args) throws SQLException {
		
		String url = "jdbc:postgresql://localhost/";
		String user = "postgres";
		String password = "postgres";
		
		String[] passwords = {"root","postgres"};
		

		for(String pass: passwords) {
			try {
				connection = DriverManager.getConnection(url,user,pass);
				System.out.println("connected to server");
				break;
			}
			catch(SQLException e) {
				//e.printStackTrace();
				System.out.println("connection failed, attempting again");
			}
			
		}
		
		if(connection == null) {
			System.out.println("no connection");
			reconnectAlertBox();
		}
		else {
			mainPage();
			//statement = connection.createStatement();
		}
		
			
		
		
		if("14.0.2" != System.getProperty("java.version")) {
			System.out.println("your java version:" +System.getProperty("java.version")+" version used for this jar: 14.0.2");
		}
		
			
		
	}

}
